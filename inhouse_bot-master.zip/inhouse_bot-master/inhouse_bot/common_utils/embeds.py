import discord

embeds_color = discord.colour.Colour.dark_red()
