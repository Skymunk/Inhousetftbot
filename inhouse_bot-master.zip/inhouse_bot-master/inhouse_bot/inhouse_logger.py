import logging

inhouse_logger = logging.getLogger("inhouse_bot")
